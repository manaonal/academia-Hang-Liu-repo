setwd("C:/Users/Memes/Desktop")
library(arm)
library(readxl)
library(MASS)
# 1. Load the data
root_df   <- read.table("counts_root.txt",   header=TRUE, sep="\t", stringsAsFactors=FALSE)
suffix_df <- read.table("counts_suffix.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
FILE.NAME <- read_excel("data4r.xlsx")
# 2. setting predictors as factors
root_df$ROOT     <- factor(root_df$ROOT)
suffix_df$Suffix <- factor(suffix_df$Suffix)
FILE.NAME$Root <- factor(FILE.NAME$Root)
FILE.NAME$Suffix <- factor(FILE.NAME$Suffix)

# 3. root- and suffix-only models without an intercept
model_root <- bayesglm(cbind(p, v) ~ 0 + ROOT, data=root_df,   family=binomial)
model_suf  <- bayesglm(cbind(p, v) ~ 0 + Suffix, data=suffix_df, family=binomial)
summary(model_root)
summary(model_suf)


# 4. two-predictor model
FILE.NAME <- within(FILE.NAME, Root <- relevel(Root, ref = "kharj") )
FILE.NAME <- within(FILE.NAME, Suffix <- relevel(Suffix, ref = "ita") )
two_fac_model <- bayesglm (Outcome ~ 1 + Root + Suffix, family  = binomial,data = FILE.NAME)
summary(two_fac_model)

# for the other two data without palatals I tried similarly with releveled merged coefficients with the least data complexity but no obvious difference
# I remember I chose suffix -I in one excel it has v and p only 1 but for the roots only kharj is so.